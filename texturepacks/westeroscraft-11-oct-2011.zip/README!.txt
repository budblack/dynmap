MOST OF THE TEXTURE AND SOUND COMPONENTS OF THIS RESOURCE PACK WERE MADE EXCLUSIVELY FOR WESTEROSCRAFT


This pack requires the very latest version of 
MCPatcher or Optifine for all features to function properly. 
Optifine, however, may not display all the connected textures correctly.

The WesterosCraftResourcePack is a mixture mainly of Dokucraft but you will 
spot bits of Doku TSC, FyreUK, John Smith and perhaps 
even leftovers from Misas Texturepack. We have made many 
alterations and additions to the pack so that quite a lot of the textures are originals only to be found in
this pack. In the future we would like the WCRP to be made up exclusively from original textures.

The sound components were created and/or arranged by Hal9007.

The sound effects used in this resource pack are based 
off of edited loops and sound samples from SoundJay.com 
or Pond5.com. Third-party samples are either public 
domain or paid for under an Attribution 3.0 licesnse.

If you want to use any of these originals feel free to do so, 
but it would be cool of you to credit all the contributors.
If you want to use any of the textures by the below mentioned 
artists, please consult the individual homepages and seek their permission.

Do not sell this resource pack! Ever.

Cheers,
Thamus_Knoward, Emoticone, Moozipan, Marken4, Hal9007


Special thanks to Doku, Misa, Hickerydickery, WantedRobot, SMP, WhitefireNeo and the following users from the DokuCommunity for their input on the respective textures:

Balloftape - Skull, CreeperHead, SurvivorHead, Redstone Lamp
Metatron - Zombie Head
Savage Alien - Empty Map
Gabriel MBR - Baked Potatoe, Pumpkin Pie
Duru - Armor Icons, Compass, Pork, Brewing Stand
Foodstamp - Armor Icons
CCCode - Chainmail Icons
LordofSax - Helmet, Chestplate, Leggins, etc.
Dark_Tundra - Banner
Wessexstock - Survivor Skin, Zombie Skin
Zaph34r - Sign
Diet Taco - Trap Door
Alexium - Cake, Cake Item
Kloporte - Bread
Noodaa - Rotten Flesh, Melon Slice
Dark Defender - ChickenMeat, Cauldron, Mushroom Block
Aceofhrts97 - Beef
Dubca7 - Cauldron
SerAaron - Book, Flagstones
Straxael - Explosion
JetStorm - Wooden Planks, Chiseled Stone Brick, SandStone
Staretta - Glasspanes
AwesomeSauceUK- NetherBrick
Recreps4444, SeanFletcher,DWSkanska, TheBaconizer - Oak Sapling, Assorted Flowers
Max - DiamondBlock
DWSkanska - Carrot, Skull, Language Buttons